-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Сен 01 2017 г., 21:52
-- Версия сервера: 5.5.52-38.3
-- Версия PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `inpkhost_trading`
--

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`) VALUES
(6, 'Мазут');

-- --------------------------------------------------------

--
-- Структура таблицы `lots`
--

CREATE TABLE IF NOT EXISTS `lots` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `count` int(11) NOT NULL,
  `count_type` varchar(255) NOT NULL,
  `characteristics` varchar(255) NOT NULL,
  `conditions_payment` varchar(255) NOT NULL,
  `conditions_shipment` varchar(255) NOT NULL,
  `terms_shipment` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `price_type` varchar(255) NOT NULL,
  `step_bet` int(11) NOT NULL,
  `start` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `stop` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `lots`
--

INSERT INTO `lots` (`id`, `name`, `count`, `count_type`, `characteristics`, `conditions_payment`, `conditions_shipment`, `terms_shipment`, `price`, `price_type`, `step_bet`, `start`, `stop`, `status`) VALUES
(9, 'Мазут', 300, 'тонн', 'кинематическая вязкость при 50*С - до 380 сСт, массовая доля мех. примесей - 0,040 %, массовая доля воды - отсутствие, массовая доля серы - 1,1%, температура застывания - не выше +4*С, плотность при 20*С - не более 933 кг/м3', '100% предоплата', 'В течении двух рабочих дней после получения', '100 % предоплаты и заявки на отгрузку', 15000, 'руб/тонна', 100, '2017-09-01 14:34:12', '2017-09-05 15:00:00', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `lots_groups`
--

CREATE TABLE IF NOT EXISTS `lots_groups` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `lot_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `lots_groups`
--

INSERT INTO `lots_groups` (`id`, `lot_id`, `group_id`) VALUES
(14, 9, 6);

-- --------------------------------------------------------

--
-- Структура таблицы `lots_users_bets`
--

CREATE TABLE IF NOT EXISTS `lots_users_bets` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `lot_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bet` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `login` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `name`, `email`, `password`) VALUES
(1, 'admin', 'Павел', 'trading@in-pk.com', '$2y$10$SY3Zm.BAMabcAq5Dh9cKL.4bxZd5G3kYBTN59cXZLPH4e0gu/HRSq'),
(10, 'user1', 'ООО \"Экспо Ресурс\"', 'neftesnab@inbox.com', '$2y$10$p5GsE5vJY.5e56JKbsb8q.3bGU7QQc0fsBoP8a1kVb7Ut3etBqDd2');

-- --------------------------------------------------------

--
-- Структура таблицы `users_groups`
--

CREATE TABLE IF NOT EXISTS `users_groups` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(5, 6, 1),
(9, 10, 6);

-- --------------------------------------------------------

--
-- Структура таблицы `winners`
--

CREATE TABLE IF NOT EXISTS `winners` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `lot_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `winners`
--

INSERT INTO `winners` (`id`, `lot_id`, `user_id`) VALUES
(14, 8, 6);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
